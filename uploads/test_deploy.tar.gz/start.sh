#!/bin/bash
echo "Starting application"
python3 test.py
