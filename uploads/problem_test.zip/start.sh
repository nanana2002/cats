#!/bin/bash
echo "Starting application"