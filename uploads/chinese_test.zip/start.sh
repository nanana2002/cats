#!/bin/bash
echo "Starting application"
python3 "测试文件.py"