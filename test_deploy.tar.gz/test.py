print("Hello from Python test!")
print("Test deployment successful!")
