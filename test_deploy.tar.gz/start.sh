#!/bin/bash
echo "Hello from test script!"
echo "Current directory: $(pwd)"
echo "Files in directory: $(ls -la)"
